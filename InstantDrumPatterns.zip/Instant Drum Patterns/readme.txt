This data consists of

200 Instant Drum Patterns
260 Instant Drum Patterns
Instant Rap Patterns

produced by Five Pin Press.

The Type 0 folder has all drums on one track.
This is good for software with a built-in drum
editor.

Type Type 1 folder has drums one sound per MIDI
track. This is good for sequencers without a drum editor.


Enjoy! joel Sampson, Publisher

http://www.fivepinpress.com

